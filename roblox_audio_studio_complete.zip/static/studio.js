/* Roblox Audio Studio - Pro DAW v2.1 Engine */
document.addEventListener('DOMContentLoaded', () => {
    console.log('Roblox Audio Studio Engine Initialized.');

    // Tab Navigation Switcher
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const targetTab = btn.getAttribute('data-tab');
            
            tabButtons.forEach(b => b.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));

            btn.classList.add('active');
            const targetElement = document.getElementById(targetTab);
            if (targetElement) {
                targetElement.classList.add('active');
            }
        });
    });

    // Map Compatibility Scanner simulation handler
    const btnScanMaps = document.getElementById('btnScanMaps');
    const mapScanIdInput = document.getElementById('mapScanIdInput');
    const mapAudioOverview = document.getElementById('mapAudioOverview');
    const overviewTitle = document.getElementById('overviewTitle');
    const overviewId = document.getElementById('overviewId');
    const permittedPlacesList = document.getElementById('permittedPlacesList');

    if (btnScanMaps && mapScanIdInput) {
        btnScanMaps.addEventListener('click', async () => {
            const assetId = mapScanIdInput.value.trim();
            if (!assetId) {
                alert('กรุณากรอก Roblox Asset ID ก่อนสแกน');
                return;
            }

            mapAudioOverview.classList.remove('hidden');
            overviewId.textContent = assetId;
            overviewTitle.textContent = 'กำลังดักฟังและตรวจสอบสิทธิ์จาก Roblox API...';
            permittedPlacesList.innerHTML = '<span style="color: var(--text-muted);">กำลังค้นหาแมพที่อนุญาต...</span>';

            try {
                // Fetch Roblox Asset Details
                const res = await fetch(`https://economy.roblox.com/v2/assets/${assetId}/details`);
                if (res.ok) {
                    const data = await res.json();
                    overviewTitle.textContent = data.Name || 'Roblox Audio';
                    document.getElementById('overviewArtist').textContent = data.Creator?.Name || 'Unknown Creator';
                } else {
                    overviewTitle.textContent = `Audio ID: ${assetId} (Custom/Public)`;
                }

                // Simulate permitted places matching typical Brookhaven/Da Hood/Thai servers
                permittedPlacesList.innerHTML = `
                    <div style="background: var(--bg-main); border: 1px solid var(--border); padding: 0.5rem 0.75rem; border-radius: 6px; font-size: 0.85rem; display:inline-block; margin: 4px;">
                        🏠 <strong>Brookhaven RP</strong> (Universe ID: 492492222) — <span style="color: var(--success);">[COMPATIBLE]</span>
                    </div>
                    <div style="background: var(--bg-main); border: 1px solid var(--border); padding: 0.5rem 0.75rem; border-radius: 6px; font-size: 0.85rem; display:inline-block; margin: 4px;">
                        🔫 <strong>Da Hood</strong> (Universe ID: 278822930) — <span style="color: var(--success);">[COMPATIBLE]</span>
                    </div>
                    <div style="background: var(--bg-main); border: 1px solid var(--border); padding: 0.5rem 0.75rem; border-radius: 6px; font-size: 0.85rem; display:inline-block; margin: 4px;">
                        🇹🇭 <strong>ซิตี้ไทยแลนด์ 2</strong> (Universe ID: 4503309821) — <span style="color: var(--success);">[COMPATIBLE]</span>
                    </div>
                `;
            } catch (err) {
                console.error(err);
                overviewTitle.textContent = `Audio ID: ${assetId} (Offline Mode)`;
                permittedPlacesList.innerHTML = '<span style="color: var(--danger);">ไม่สามารถเชื่อมต่อ Roblox API ตรงได้เนื่องจาก CORS Policy (แนะนำให้ใช้บอท Discord หรือรันผ่าน Backend Proxy)</span>';
            }
        });
    }
});
